from django.shortcuts import render,redirect
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import load_model
from django.http import HttpResponse
import os
from .models import Image


Classes=['Normal', 'Sick']

def index(request):
    return render(request,'index.html')


def result(request):
    if request.method=='POST':
        m=int(request.POST['alg'])
        file=request.FILES['file']
        fn=Image(image=file)
        fn.save()
        path=os.path.join('webapp/static/images/',file.name)
        acc=pd.read_csv("webapp/Accuracy.csv")

        if m==1:
            new_model=load_model("webapp\CNN.h5")
            test_image=image.load_img(path,target_size=(256,256))
            test_image=image.img_to_array(test_image)
            test_image/=255
            a=acc.iloc[m -1,1]
        else:
            new_model=load_model("webapp\Mobilenet.h5")
            test_image=image.load_img(path,target_size=(256,256))
            test_image=image.img_to_array(test_image)
            test_image/=255
            a=acc.iloc[m-1,1]

        test_image=np.expand_dims(test_image,axis=0)
        result=new_model.predict(test_image)
        pred=Classes[np.argmax(result)]
        print(pred)

        if pred=="Normal":
            msg="No Treatment Requried"
        else:
            msg='Patient needs the Treatment'
        
        return render(request,'result.html',{'text':pred,'msg':msg,'path':'static/images/'+file.name,'a':round(a*100,3)})
    return render(request,'result.html')

